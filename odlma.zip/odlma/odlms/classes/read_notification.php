<?php
require_once '../config.php';


$host = DB_SERVER;
$username = DB_USERNAME;
$password = DB_PASSWORD;
$database = DB_NAME;

$conn = new mysqli($host, $username, $password, $database);

$data = ($_GET['id']);

$stmt = "UPDATE notification_list SET isRead = '1' WHERE id= " . $data;

$result = mysqli_query($conn, $stmt);

if ($result) {
    echo json_encode(array('status' => 'success'));
} else {
    echo json_encode(array('status' => 'incorrect', 'error' => mysqli_error($conn)));
}
