<?php
require_once '../config.php';


$host = DB_SERVER;
$username = DB_USERNAME;
$password = DB_PASSWORD;
$database = DB_NAME;

$conn = new mysqli($host, $username, $password, $database);

$data = ($_POST['id']);

$stmt = "SELECT n.* from notification_list n LEFT JOIN appointment_list a ON n.userId = a.id where a.client_id = ". $data ." and isRead = '0'";

$result = mysqli_query($conn, $stmt);


if (mysqli_num_rows($result) > 0) {
    $res = mysqli_fetch_all($result, MYSQLI_ASSOC);

    echo json_encode(array('status' => 'success', 'data' => $res));
} else {
    echo json_encode(array('status' => 'incorrect', 'error' => $this->conn->error));
}
